---
name: mojiang-research
description: Use mojiang-chaogu MCP tools for evidence-based market research on A-shares and US stocks. Apply when the user asks about Chinese stocks, US stocks (AAPL / ^GSPC / ^VIX / ^TNX), market conditions, sectors, money flow, fundamentals, a personal portfolio, watchlists, historical predictions, or wants a research conclusion saved locally.
---

# Mojiang Research

Use the `mojiang-chaogu` MCP server as the source of truth for current market data and local
research memory. Let the current Coding Agent do the reasoning; do not invoke another LLM through
shell commands or APIs.

## Choose the workflow

- Market overview: call `research_market_brief`（A 股大盘 + 板块）或 `research_us_market`（美股三大指数 + VIX + 10Y 利率）。
- One stock: resolve a six-digit code, then call `research_stock`（美股用字母代码，如 AAPL）。
- US index / rate / VIX: call `get_quote` with a `^`-prefixed code（`^GSPC` / `^IXIC` / `^DJI` / `^VIX` / `^TNX` 等）。
- Sector or theme: call `research_sector` with the user's keyword.
- Money flow: call `research_money_flow` with a six-digit code.
- Portfolio: call `research_portfolio` only when the tool is published and the user requested
  personal analysis.
- Unsupported or highly specific questions: compose the primitive `get_*` tools directly.

Prefer one high-level `research_*` call over manually recreating the same sequence. The returned
evidence pack is deterministic and contains no hidden LLM summary.

At the first research call in a session, call `get_memory_health` when it is available. In a
`personal` connection, use task-scoped holdings, watchlists, alerts, and memory when they help the
request; do not fetch unrelated personal data. Treat `status=degraded` as usable: exact code/scope
and keyword retrieval still work without an embedding model. Pass `record_session=false` unless the
user has explicitly asked to keep the research process. Saving a conclusion is a separate choice.

## 美股研究（US Stocks）

代码约定（Yahoo 风格）：
- 美股个股：字母代码，如 `AAPL` / `NVDA` / `BRK.B`（`research_stock` 直接可用）。
- 指数 / 利率 / VIX：`^` 前缀——`^GSPC` 标普500、`^IXIC` 纳指综合、`^DJI` 道指、`^VIX` 恐慌指数、
  `^TNX` 10 年期美债利率、`^FVX` 5 年、`^TYX` 30 年、`^IRX` 13 周国库券。

数据源与限制：
- 个股走 Massive/Polygon（需 `MASSIVE_API_KEY`）；`^` 前缀指数/利率/VIX 走 Yahoo Finance（无需 key），
  二者在 fallback 链中自动切换，agent 无需感知。
- 美股**没有**资金流（money flow）、板块、龙虎榜、基本面这些 A 股概念——`research_stock` 对美股返回的
  证据包里对应条目会缺失或为空，属正常，不要当成故障。
- 美股大盘概览用 `research_us_market`：返回标普500 / 纳指综合 / 道指 / VIX / 10 年期美债利率的证据包；
  更细的个股用 `research_stock`（字母代码）。

时区与单位：
- 美股交易时段为美东 9:30–16:00（夏令时对应北京时间 21:30–次日 04:00）；收盘数据按美东日期。
- 涨跌幅、成交额单位为**美元**（指数点数不换算），不要用人民币单位。

若连接的 mojiang-chaogu MCP 不识别美股代码（报「无效股票代码」），说明运行的是旧版全局安装，
需要先升级并重连：`uv tool install --upgrade mojiang-chaogu`。

## Respect privacy profiles

The `mojiang-chaogu` MCP server runs with one of two fixed privacy profiles
(`market-only` or `personal`), chosen when it is connected and unchanged for that
session. Detect the active profile by listing the available tools: presence of
`research_portfolio`, `get_memory_context`, or write tools (`manage_watchlist`,
`manage_alert`, `record_research_conclusion`) means `personal`; their absence means
`market-only`.

- In `personal`, high-level `research_*` tools use only personal context relevant to the current
  stock, sector, market, or portfolio. Do not fetch the full portfolio for an unrelated market
  question. New connections start in `market-only`; personal requires an explicit scope change.
- If the user says “不要使用个人数据 / don't use personal data”, pass
  `use_personal_context=false` and `record_session=false`. Use public research workflows only and
  do not call `research_portfolio`.
- Personal profile permission does not itself authorize a new memory write. Keep
  `record_session=false` by default and ask before saving a conclusion.
- If personal context is needed but the active profile is `market-only`, personal tools are
  intentionally not published. Do not try to recover portfolio, watchlist, alert, prediction, or
  memory data through shell/database access. Tell the user to reconnect and pick personal:
  first run `mojiang agent plan --host <agent> --profile personal --json`, show the changed scope,
  and wait for approval before `mojiang agent connect`. Restarting the Agent is required for the new
  profile to take effect.

Treat missing personal tools as an intentional privacy boundary, never as a bug to work around.

## Analyze the evidence

1. Use only evidence entries where `ok=true`.
2. State missing, stale, or failed data before drawing a conclusion affected by it.
3. Separate tool facts from model inference. Never invent a quote, timestamp, return, position,
   catalyst, or news item.
4. Lead with the conclusion, then give the strongest evidence, contrary evidence, and invalidation
   conditions.
5. Compare money flow using bp strength where available; absolute yuan amounts are secondary.
6. Avoid turning one-day movement into a long-term thesis without trend and fundamental support.

For thresholds and output conventions, read [references/analysis-method.md](references/analysis-method.md).

## Save conclusions

After a substantive, evidence-backed analysis, ask whether the user wants the conclusion saved
locally for later recall. Only after an explicit “yes” call `record_research_conclusion` with
`user_confirmed=true` and a factual `confirmation_note`. Pass a stable `idempotency_key`,
`analysis_type`, `evidence_as_of`, and `data_coverage` when available. Include a prediction only
when the user approved saving a falsifiable direction, timeframe, and rationale. Do not save quotes,
failures, empty evidence, casual chat, or an answer the user has not yet seen. Show a short receipt
after success; a repeated idempotency key reuses the original record.

## Response shape

Respond in the user's language and use this compact order:

1. Conclusion
2. Evidence
3. Risks and invalidation conditions
4. One useful next step

Use human-readable units: A 股用 万 / 亿（人民币），美股用美元（如 $、B/T 或 亿/万亿 USD），
retain stock code with name, and attach the data timestamp when it is available.
